import DashboardHome from "./DashboardHome";

export default function DashboardLayout() {
  return <DashboardHome />;
}
